import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'footerbar',
  templateUrl: 'footer.component.html'
})

export class FooterComponent { }